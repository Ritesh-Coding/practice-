from django.apps import AppConfig


class JobFormConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'job_form'
